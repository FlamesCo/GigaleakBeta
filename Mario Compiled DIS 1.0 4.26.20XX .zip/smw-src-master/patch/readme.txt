As you are probably familiar with IPS patches for binary files, ".diff"
files are used for text files. Run patch.bat and press "C" to create a
new patch, or "A" to apply an existing patch. Then follow the on-screen
instructions.

Included in the "expand_rom_1mb" folder is a basic patch to expand the
ROM to 1MB. Open the folder and run "patch.bat" to apply, then compile
the source code. Make sure the source code is unmodified.
